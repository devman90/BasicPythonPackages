README FIRST
============

Please do not add new templates for nbconvert here.

In order to speed up the distribution of nbconvert templates and make it
simpler to share such contributions, we encourage [sharing those links on our
wiki
page](https://github.com/ipython/ipython/wiki/Cookbook:%20nbconvert%20templates).
