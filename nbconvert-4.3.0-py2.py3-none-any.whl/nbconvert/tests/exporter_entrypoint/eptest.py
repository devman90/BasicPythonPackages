from nbconvert.exporters import Exporter

class DummyExporter(Exporter):
    pass
