"""Deprecated; import from IPython.lib.lexers instead."""
from warnings import warn

warn("nbconvert.utils.lexers is deprecated. Use IPython.lib.lexers")

from IPython.lib.lexers import *
